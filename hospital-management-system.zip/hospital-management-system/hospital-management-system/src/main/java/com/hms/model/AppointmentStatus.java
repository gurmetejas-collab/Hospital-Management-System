package com.hms.model;

public enum AppointmentStatus {
    PENDING,
    APPROVED,
    REJECTED,
    COMPLETED
}
