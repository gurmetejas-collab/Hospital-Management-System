package com.hms.util;

/**
 * ⚠️ DISABLED UTILITY
 * 
 * This class is intentionally NOT annotated with @Component
 * so it will NOT run automatically on application startup.
 *
 * Use it ONLY for manual password generation if needed.
 */
public class PasswordGen {

    // Manual helper only — no auto execution
}
